
import Acme.MainFrame;

public class MShockProg {
    public static void main(String[] args){
        Mshock.Mshock mshock = new Mshock.Mshock();
       MainFrame mshockMainFrame = new MainFrame(mshock, 750, 500);
    }
}
