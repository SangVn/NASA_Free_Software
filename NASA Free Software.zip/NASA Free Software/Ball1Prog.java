
import Acme.MainFrame;

public class Ball1Prog {
    public static void main(String[] args){
        FoilSimb.Ball ball = new FoilSimb.Ball();
        MainFrame ballMainFrame = new MainFrame(ball, 710, 550);  
    }
}
