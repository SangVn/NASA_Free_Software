
import Acme.MainFrame;

public class TunoProg {
    public static void main(String[] args){
        Tuno.Tuno tuno = new Tuno.Tuno();
        MainFrame tunoMainFrame = new MainFrame(tuno, 720, 540); 
    }
}
