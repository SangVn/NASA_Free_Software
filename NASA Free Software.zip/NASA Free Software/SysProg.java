
import Acme.MainFrame;

public class SysProg {
    public static void main(String[] args){
        Sys.Sys sys = new Sys.Sys();
        MainFrame sysMainFrame = new MainFrame(sys, 710, 675); 
    }
}
