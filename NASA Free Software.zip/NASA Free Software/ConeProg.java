
import Acme.MainFrame;

public class ConeProg {
    public static void main(String[] args){
        Shockc.Shock shockc = new Shockc.Shock();
        MainFrame shockcMainFrame = new MainFrame(shockc, 750, 500);
    }
}
