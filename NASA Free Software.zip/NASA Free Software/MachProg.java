
import Acme.MainFrame;

public class MachProg {
    public static void main(String[] args){
        Mach.Mach mach = new Mach.Mach();
        MainFrame machFoilMainFrame = new MainFrame(mach, 440, 390);
    }
}
