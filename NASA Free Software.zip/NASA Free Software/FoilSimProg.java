
import Acme.MainFrame;

public class FoilSimProg {
    public static void main(String[] args){
        //EngineSimr.Range range = new EngineSimr.Range();
        //MainFrame rangeMainFrame = new MainFrame(range, 710, 550);

        FoilSim.Foil foilSim = new FoilSim.Foil();
        MainFrame foilSimMainFrame = new MainFrame(foilSim, 750, 500);

        //Tunl.Foil tunl = new Tunl.Foil();
				//MainFrame tunlMainFrame = new MainFrame(tunl, 750, 500);

        //WTest.Wys wTest = new WTest.Wys();
        //MainFrame wTestMainFrame = new MainFrame(wTest, 740, 690);

        //Mach.Mach mach = new Mach.Mach();
        //MainFrame machFoilMainFrame = new MainFrame(mach, 440, 390);

        //Isentrop.Isentrop isentrop = new Isentrop.Isentrop();
        //MainFrame isentropMainFrame = new MainFrame(isentrop, 630, 345);

        //Shock.Shock shock = new Shock.Shock();
        //MainFrame shockMainFrame = new MainFrame(shock, 645, 435);

        //Shockc.Shock shockc = new Shockc.Shock();
        //MainFrame shockcMainFrame = new MainFrame(shockc, 750, 500);

        //Mshock.Mshock mshock = new Mshock.Mshock();
        //MainFrame mshockMainFrame = new MainFrame(mshock, 750, 500);

        //Moc.Moc moc = new Moc.Moc();
        //MainFrame mocMainFrame = new MainFrame(moc, 750, 820);

        //Nozzle.Nozzle nozzle = new Nozzle.Nozzle();
        //MainFrame nozzleMainFrame = new MainFrame(nozzle, 750, 500);

        //Sfs.Moc sfs = new Sfs.Moc();
        //MainFrame sfsMainFrame = new MainFrame(sfs, 750, 550);

        //EngineSimU.Turbo turbo = new EngineSimU.Turbo();
        //MainFrame turboMainFrame = new MainFrame(turbo, 750, 550);

        //FoilSimU.Foil foilSimU = new FoilSimU.Foil();
        //MainFrame foilSimUMainFrame = new MainFrame(foilSimU, 750, 550);	
    }
}
