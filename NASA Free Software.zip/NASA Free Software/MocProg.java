
import Acme.MainFrame;

public class MocProg {
    public static void main(String[] args){
        Moc.Moc moc = new Moc.Moc();
        MainFrame mocMainFrame = new MainFrame(moc, 750, 820);
    }
}
