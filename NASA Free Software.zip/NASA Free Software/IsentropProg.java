
import Acme.MainFrame;

public class IsentropProg {
    public static void main(String[] args){
        Isentrop.Isentrop isentrop = new Isentrop.Isentrop();
        MainFrame isentropMainFrame = new MainFrame(isentrop, 630, 345);
    }
}
