
import Acme.MainFrame;

public class GeomProg {
    public static void main(String[] args){
        Geom.Design design = new Geom.Design();
        MainFrame designMainFrame = new MainFrame(design, 710, 675); 
    }
}
