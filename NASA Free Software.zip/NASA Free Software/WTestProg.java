
import Acme.MainFrame;

public class WTestProg {
    public static void main(String[] args){
        WTest.Wys wTest = new WTest.Wys();
        MainFrame wTestMainFrame = new MainFrame(wTest, 740, 690);
    }
}
