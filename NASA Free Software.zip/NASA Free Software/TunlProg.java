
import Acme.MainFrame;

public class TunlProg {
    public static void main(String[] args){
				Tunl.Foil tunl = new Tunl.Foil();
        MainFrame tunlMainFrame = new MainFrame(tunl, 750, 500);
    }
}
