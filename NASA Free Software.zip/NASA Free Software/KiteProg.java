
import Acme.MainFrame;

public class KiteProg {
    public static void main(String[] args){
        KiteModeler.Kite kite = new KiteModeler.Kite();
        MainFrame kiteMainFrame = new MainFrame(kite, 710, 400); 
    }
}
