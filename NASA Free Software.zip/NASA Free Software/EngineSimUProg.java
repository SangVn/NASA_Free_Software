
import Acme.MainFrame;

public class EngineSimUProg {
    public static void main(String[] args){
        EngineSimU.Turbo turbo = new EngineSimU.Turbo();
        MainFrame turboMainFrame = new MainFrame(turbo, 750, 550);
    }
}
