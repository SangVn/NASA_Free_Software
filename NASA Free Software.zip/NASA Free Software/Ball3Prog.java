
import Acme.MainFrame;

public class Ball3Prog {
    public static void main(String[] args){
        Hit.Hit hit = new Hit.Hit();
        MainFrame hitMainFrame = new MainFrame(hit, 710, 550);  
    }
}
