
import Acme.MainFrame;

public class Ball4Prog {
    public static void main(String[] args){
        WHit.WHit hit = new WHit.WHit();
        MainFrame hitMainFrame = new MainFrame(hit, 910, 550);  
    }
}
