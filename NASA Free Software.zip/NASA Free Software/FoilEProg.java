
import Acme.MainFrame;

public class FoilEProg {
    public static void main(String[] args){
        FoilSim.Foil foilSim = new FoilSim.Foil();
        MainFrame foilSimMainFrame = new MainFrame(foilSim, 750, 500);  
    }
}
