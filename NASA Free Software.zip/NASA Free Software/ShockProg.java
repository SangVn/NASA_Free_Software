
import Acme.MainFrame;

public class ShockProg {
    public static void main(String[] args){
        Shock.Shock shock = new Shock.Shock();
        MainFrame shockMainFrame = new MainFrame(shock, 645, 435);
    }
}
