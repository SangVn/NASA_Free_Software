
import Acme.MainFrame;

public class AtmosProg {
    public static void main(String[] args){
        Atmos.Atmos atmos = new Atmos.Atmos();
        MainFrame atmosMainFrame = new MainFrame(atmos, 710, 400); 
    }
}
