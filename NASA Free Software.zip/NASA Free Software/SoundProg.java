
import Acme.MainFrame;

public class SoundProg {
    public static void main(String[] args){
        Sound.Sound sound = new Sound.Sound();
        MainFrame soundMainFrame = new MainFrame(sound, 600, 300); 
    }
}
