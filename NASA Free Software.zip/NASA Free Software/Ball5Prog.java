
import Acme.MainFrame;

public class Ball5Prog {
    public static void main(String[] args){
        Soccer.Ball ball = new Soccer.Ball();
        MainFrame ballMainFrame = new MainFrame(ball, 910, 550);  
    }
}
