
import Acme.MainFrame;

public class RocketProg {
    public static void main(String[] args){
        Rocket.Rocket rocket = new Rocket.Rocket();
        MainFrame rocketMainFrame = new MainFrame(rocket, 710, 450); 
    }
}
