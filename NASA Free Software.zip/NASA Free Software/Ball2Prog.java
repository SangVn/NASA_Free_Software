
import Acme.MainFrame;

public class Ball2Prog {
    public static void main(String[] args){
        BallKiosk.Ball ball = new BallKiosk.Ball();
        MainFrame ballMainFrame = new MainFrame(ball, 910, 700);  
    }
}
