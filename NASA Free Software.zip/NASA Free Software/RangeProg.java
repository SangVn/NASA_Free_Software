
import Acme.MainFrame;

public class RangeProg {
    public static void main(String[] args){
        EngineSimr.Range range = new EngineSimr.Range();
        MainFrame rangeMainFrame = new MainFrame(range, 710, 550); 
    }
}
