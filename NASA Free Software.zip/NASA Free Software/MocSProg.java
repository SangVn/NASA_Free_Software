
import Acme.MainFrame;

public class MocSProg {
    public static void main(String[] args){
        MocS.Moc moc = new MocS.Moc();
        MainFrame mocMainFrame = new MainFrame(moc, 900, 550);
    }
}
