
import Acme.MainFrame;

public class Foil3Prog {
    public static void main(String[] args){
        FoilSimU.Foil foilSimU = new FoilSimU.Foil();
        MainFrame foilSimUMainFrame = new MainFrame(foilSimU, 750, 550);
    }
}
